package com.mobioos.bankweb.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.mobioos.bankweb.models.cards.ICreditCard;

/**
 * A bank account.
 */
public class Account {
  private long id;
  private double balance;
  private String currency;
  private ICreditCard creditCard;
  private boolean allowOverdraft = false;

  public Account(long id, double initial, String currency, ICreditCard creditCard) {
    this.id = id;
    this.balance = initial;
    this.currency = currency;
    this.creditCard = creditCard;
  }

  public long getId() {
    return id;
  }

  public double getBalance() {
    return balance;
  }

  public String getCurrency() {
    return currency;
  }

  // Ignore this file while converting account instances into JSON objects
  @JsonIgnore
  public ICreditCard getCreditCard() {
    return creditCard;
  }

  public void setCreditCard(ICreditCard creditCard) {
    this.creditCard = creditCard;
  }

  /**
   * Depose money into the account.
   * 
   * @param amount The amount to depose.
   * @return An operation message specifying if the operation is successful or
   *         not.
   */
  public OperationMessage deposit(double amount) {
    this.balance += this.creditCard.deposit(amount);
    return this.createBalanceOkMessage();
  }

  /**
   * Withdraw money from the account.
   * 
   * @param amount The amount to withdraw.
   * @return An operation message specifying if the operation is successful or
   *         not.
   */
  public OperationMessage withdraw(double amount) {
    double toWithdraw = this.creditCard.withdraw(amount);
    double sum = this.balance - toWithdraw;
    // Only perform the operation is the remaining balance is positive OR if
    // overdrafts are authorized
    if (sum >= 0 || allowOverdraft) {
      this.balance -= toWithdraw;
      return this.createBalanceOkMessage();
    } else {
      return this.createOverdraftKoMessage();
    }
  }

  /**
   * Create a successful operation message.
   * 
   * @return A successful operation message.
   */
  private OperationMessage createBalanceOkMessage() {
    return OperationMessage.createOkMessage(this.balance);
  }

  /**
   * Create a failure operation message (because of non-allowed account overdraft)
   * 
   * @return A failure operation message.
   */
  private OperationMessage createOverdraftKoMessage() {
    return OperationMessage.createKoMessage("Unauthorized overdraft",
        "You cannot perform this withdraw operation because you do not have enough fund", this.balance);
  }
}