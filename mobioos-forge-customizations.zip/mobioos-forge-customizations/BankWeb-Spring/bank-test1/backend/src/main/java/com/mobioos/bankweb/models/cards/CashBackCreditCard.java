package com.mobioos.bankweb.models.cards;

/**
 * A cashback credit card.
 * Change the deposit behavior. Depose the given amount of money + 1% of the
 * money.
 * Withdraw behavior is classic.
 */
public class CashBackCreditCard implements ICreditCard {
    public double deposit(double amount) {
        System.out.println("Withdraw: " + (amount + (amount * 0.01)));
        return amount + (amount * 0.01);
    }

    public double withdraw(double amount) {
        return amount;
    }
}