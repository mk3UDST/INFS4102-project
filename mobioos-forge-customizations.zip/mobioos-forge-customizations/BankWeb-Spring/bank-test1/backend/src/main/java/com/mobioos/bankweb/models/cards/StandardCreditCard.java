package com.mobioos.bankweb.models.cards;

/**
 * The standard credit card.
 */
public class StandardCreditCard implements ICreditCard {
    public double deposit(double amount) {
        return amount;
    }

    public double withdraw(double amount) {
        return amount;
    }
}