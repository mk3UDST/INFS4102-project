package com.mobioos.bankweb.models.cards;

/**
 * Strategy for a credit card.
 */
public interface ICreditCard {
    /**
     * Deposit money.
     * 
     * @param amount The amount of money to deposit.
     * @return The amount of money remaining on the account after the operation.
     */
    double deposit(double amount);

    /**
     * Withdraw money.
     * 
     * @param amount The amount of money to withdraw.
     * @return The amount of money remaining on the account after the operation.
     */
    double withdraw(double amount);
}