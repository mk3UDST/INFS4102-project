package com.mobioos.bankweb.models;

/**
 * An message sent to the client reporting on an operation success or failure.
 */
public class OperationMessage {
    private static String OK_STATUS = "ok";
    private static String KO_STATUS = "ko";
    private String status;
    private String title;
    private String message;
    private double balance;

    private OperationMessage(String status, String title, String message, double balance) {
        this.status = status;
        this.title = title;
        this.message = message;
        this.balance = balance;
    }

    /**
     * Create a success message with the account balance.
     * 
     * @param balance The account balance.
     * @return The success message.
     */
    public static OperationMessage createOkMessage(double balance) {
        return new OperationMessage(OperationMessage.OK_STATUS, "", "", balance);
    }

    /**
     * Create a failure message.
     * 
     * @param title   The title of the failure.
     * @param message The message of the failure.
     * @param balance The account balance.
     * @return The failure message.
     */
    public static OperationMessage createKoMessage(String title, String message, double balance) {
        return new OperationMessage(OperationMessage.KO_STATUS, title, message, balance);
    }

    public String getStatus() {
        return status;
    }

    public String getTitle() {
        return title;
    }

    public String getMessage() {
        return message;
    }

    public double getBalance() {
        return balance;
    }
}