package com.mobioos.bankweb.models.cards;

/**
 * A cashback credit card.
 * Deposit behavior unchanged.
 * Change the withdraw behavior. Perform the withdrawal every two operations
 * (stacks the amount to withdraw).
 */
public class DeferredCreditCard implements ICreditCard {

    private int withdrawCpt;
    private double deferredWithdraw;

    public DeferredCreditCard() {
        this.withdrawCpt = 0;
        this.deferredWithdraw = 0;
    }

    public double deposit(double amount) {
        return amount;
    }

    public double withdraw(double amount) {
        this.withdrawCpt++;
        // We perform the withdraw every two calls
        if (withdrawCpt % 2 == 0) {
            double toWithdraw = this.deferredWithdraw + amount;
            this.deferredWithdraw = 0;
            return toWithdraw;
        } else {
            this.deferredWithdraw += amount;
            return 0;
        }
    }
}