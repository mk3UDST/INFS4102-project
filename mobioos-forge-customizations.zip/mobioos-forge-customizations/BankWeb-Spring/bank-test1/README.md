# Execution

To launch the application, you will need two terminals to start the front and backend.
- Start the frontend:
  1. Go to the `frontend` folder: `cd frontend`
  2. Install the dependencies and start the local web server: `npm i && npm start`
- Start the Backend:
  1. Go to the `backend` folder: `cd backend`
  2. Build and start the backend: `mvn spring-boot:run`